from flask import Flask, request, render_template
import joblib

app = Flask(__name__)
model = joblib.load("traffic_model.pkl")  # Replace with your model file

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        input_features = [float(request.form[key]) for key in [
            'holiday', 'temp', 'rain', 'snow', 'weather',
            'year', 'month', 'day', 'hour', 'minute', 'second'
        ]]
        prediction = model.predict([input_features])[0]
        return f"""
        <h1 style='text-align:center;color:yellow;'>Predicted Average Traffic Volume</h1>
        <h2 style='text-align:center;color:lightgreen;'>🔢 {int(prediction)} vehicles</h2>
        <div style='text-align:center;'>
            <a href='/' style='color:cyan;'>⬅️ Predict Again</a>
        </div>
        """
    except Exception as e:
        return f"<h3 style='color:red;text-align:center;'>Error: {e}</h3>"

if __name__ == '__main__':
    app.run(debug=True)
